﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace u2_SummativeNolan
{
    class Body
    {
        public enum Direction { left, right};
        private Point location;
        private double angle;
        private Vector speed;
        Rect boundingBox;
        Rectangle sprite;


        public Body(Point loc,double size, Uri image )
        {
            this.speed = new Vector();
            this.angle = 0;
            this.location = loc;
            this.sprite = new Rectangle();
            this.boundingBox.Width = size;
            this.boundingBox.Height = size;
            this.sprite.Width = size;
            this.sprite.Height = size;
            this.sprite.Fill =new ImageBrush(new BitmapImage(image));
            Console.WriteLine("new body");
        }
        public void Turn(Direction d)
        {
            switch(d)
            {
                case Direction.left:
                    this.angle -= 5;
                    break;
                case Direction.right:
                    this.angle += 5;
                    break;
                default:
                    break;
            }
        }
        public bool collisionCheck(Body b)
        {
            //Console.WriteLine(this.boundingBox.X + ", " + this.boundingBox.Y);
            return ! (this.boundingBox.X > b.boundingBox.X + b.boundingBox.Width
                || this.boundingBox.X + this.boundingBox.Width < b.boundingBox.X
                || this.boundingBox.Y > b.boundingBox.Y + b.boundingBox.Height
                || this.boundingBox.Y + this.boundingBox.Height < b.boundingBox.Y);
        }
        public Rectangle getSprite()
        {
            return this.sprite;
        }
        public Point getLocation()
        {
            return this.location;
        }
        public Vector getSpeed()
        {
            return this.speed;
        }
        public void setSpeed(Vector v)
        {
            this.speed = v;
        }
        public double getAngle()
        {
            return this.angle;
        }
        public double getSize()
        {
            return this.sprite.Width;
        }
        public virtual void update()
        {
            //Console.WriteLine(this.boundingBox.X + ", " + this.boundingBox.Y);
            this.location = Point.Add(this.location, speed);
            this.boundingBox.X = this.location.X;
            this.boundingBox.Y = this.location.Y;
        }
    }
}